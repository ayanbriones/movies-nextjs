(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[233],{6666:function(e,r,t){Promise.resolve().then(t.bind(t,6798))},6798:function(e,r,t){"use strict";t.r(r),t.d(r,{default:function(){return s}});var n=t(6705),o=t(3190);function s(){let{pending:e}=(0,o.experimental_useFormStatus)();return(0,n.jsx)("button",{type:"submit",disabled:e,className:"bg-teal-500 px-4 py-2 rounded-lg my-2",children:e?(0,n.jsx)(n.Fragment,{children:"Loading..."}):(0,n.jsx)(n.Fragment,{children:"Add Comment"})})}},9991:function(e,r,t){"use strict";/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var n=t(955),o=Symbol.for("react.element"),s=Symbol.for("react.fragment"),u=Object.prototype.hasOwnProperty,i=n.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,f={key:!0,ref:!0,__self:!0,__source:!0};function a(e,r,t){var n,s={},a=null,c=null;for(n in void 0!==t&&(a=""+t),void 0!==r.key&&(a=""+r.key),void 0!==r.ref&&(c=r.ref),r)u.call(r,n)&&!f.hasOwnProperty(n)&&(s[n]=r[n]);if(e&&e.defaultProps)for(n in r=e.defaultProps)void 0===s[n]&&(s[n]=r[n]);return{$$typeof:o,type:e,key:a,ref:c,props:s,_owner:i.current}}r.Fragment=s,r.jsx=a,r.jsxs=a},6705:function(e,r,t){"use strict";e.exports=t(9991)}},function(e){e.O(0,[121,114,744],function(){return e(e.s=6666)}),_N_E=e.O()}]);